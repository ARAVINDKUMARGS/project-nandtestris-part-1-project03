# project-nandtestris-part-1-project03
project-03

# ✅ **README.md (Ready to Copy)**

```
# 🧠 Nand2Tetris – Project 3: Sequential Logic (Memory)

This repository contains the full HDL implementation of **Project 3** from the
Nand2Tetris course: _"The Elements of Computing Systems"_.

Project 3 focuses on building **sequential logic** using the primitive `DFF`.
The goal is to construct the memory hierarchy required for the Hack Computer.

---

## 📂 Included Chips

### ✔ 1-bit & Register-level Memory
- `Bit.hdl` — Single 1-bit storage cell  
- `Register.hdl` — 16-bit register  

### ✔ RAM Components
- `RAM8.hdl`  
- `RAM64.hdl`  
- `RAM512.hdl`  
- `RAM4K.hdl`  
- `RAM16K.hdl` — Full 16K memory module used in Hack computer  

### ✔ Program Counter
- `PC.hdl` — Handles increments, loading, and reset signals  

---

## 🧪 Test Status

All components:
- ✔ Pass official **Hardware Simulator** tests  
- ✔ Conform to Nand2Tetris spec  
- ✔ Use only allowed chips from previous projects  

---

## 🚀 Project Objective

This project teaches the fundamentals of:
- Sequential circuits  
- State, clocks, and flip-flops  
- Building memory hierarchies  
- Program counter operation  

By the end of this project, you complete the **entire memory subsystem** of the Hack Computer.

---

## 📦 Repository Structure

```

project-3/
│
├── Bit.hdl
├── Register.hdl
├── RAM8.hdl
├── RAM64.hdl
├── RAM512.hdl
├── RAM4K.hdl
├── RAM16K.hdl
├── PC.hdl
│
├── README.md
├── LICENSE
└── .gitignore

```

---

## 📘 References

- Nand2Tetris Official Website: https://www.nand2tetris.org  
- *The Elements of Computing Systems* – Chapter 3  
- Hardware Simulator Guide  
- Project 3 Specification (Sequential Logic)  

---

## 🙌 Credits

Created by Aravind Kumar GS (Meenakshi College of Engineering)  
Guided by Nand2Tetris curriculum.

---

```

---

# ✅ **LICENSE (MIT License)**

```
MIT License

Copyright (c) 2025 

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

---

# ✅ **GitHub Release Description (Ready to copy)**

```
# 📦 Project 3 – Sequential Logic (Memory) | Nand2Tetris

This release contains the complete HDL implementation for **Project 3** of the
Nand2Tetris course.

## Included HDL Chips
- Bit.hdl  
- Register.hdl  
- RAM8.hdl  
- RAM64.hdl  
- RAM512.hdl  
- RAM4K.hdl  
- RAM16K.hdl  
- PC.hdl  

## Test Status
✔ Fully passes all official tests  
✔ Compatible with Nand2Tetris Hardware Simulator  
✔ Uses only permitted chips  

## Upload Instructions
Attach the ZIP file containing all HDL files:
- **project3-hdl.zip**

## References
Nand2Tetris – https://www.nand2tetris.org  
The Elements of Computing Systems – Chapter 3  
